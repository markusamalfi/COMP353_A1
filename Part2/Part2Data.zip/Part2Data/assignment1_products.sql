-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: assignment1
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'Better available.','2025-10-26',110.62,44.64,'Kennedy Courts','blue'),(2,2,'Course nothing.','2022-01-11',34.71,21.99,'Linda Mission','black'),(3,3,'Position.','2025-08-02',122.65,41.33,'Alvarez Corners','white'),(4,4,'Onto friend couple.','2020-02-20',290.42,40.26,'Wilson Forges','yellow'),(5,5,'Day.','2021-07-28',182.94,29.59,'Timothy Stream','yellow'),(6,6,'Current grow rule.','2024-11-05',31.50,38.00,'Heidi Ford','blue'),(7,7,'Score from animal.','2022-05-22',137.92,33.18,'John Orchard','white'),(8,8,'Interest.','2025-12-20',84.96,35.41,'Barton Station','green'),(9,9,'Study candidate.','2020-02-15',192.32,30.51,'Herring Mall','black'),(10,10,'President stage.','2025-06-26',11.72,21.57,'Wilson Drives','red'),(11,11,'Onto across character.','2022-11-01',120.43,13.38,'Clarke Stravenue','white'),(12,12,'Rock few structure.','2022-07-18',39.58,46.11,'Rodriguez Points','white'),(13,13,'Billion.','2023-05-08',28.33,37.08,'West Overpass','black'),(14,14,'Sell cut market.','2022-03-07',249.53,4.50,'Danielle Union','black'),(15,15,'Your play themselves.','2024-08-13',214.16,8.70,'Alec Squares','red'),(16,16,'Than leave.','2023-02-27',263.13,40.71,'Santana Parkway','blue'),(17,17,'Few now.','2022-10-30',5.70,41.23,'Trevor Greens','black'),(18,18,'Letter learn big sing.','2020-03-03',11.44,45.74,'Carmen Curve','unknown'),(19,19,'Son true their.','2025-10-16',205.89,28.14,'April Turnpike','green'),(20,20,'International not.','2020-09-18',178.20,0.94,'Robert Courts','blue');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-15 11:06:16
