-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: assignment1
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `donors`
--

LOCK TABLES `donors` WRITE;
/*!40000 ALTER TABLE `donors` DISABLE KEYS */;
INSERT INTO `donors` VALUES (1,'Megan','Chang','A','1957-04-16',6312,'Sheppard Oval','Montreal','53576','Maryland','Male','489-46-9559','365-623-8961','juancampos@lloyd.org','Unknown'),(2,'Ryan','Carr','n','1992-02-19',4105,'Ramos Pike','Sherbrooke','34644','Arkansas','Female','825-71-0231','201-847-2208','ypage@garrett.com','Unknown'),(3,'Christopher','Flores','G','1987-10-31',7816,'Kevin Highway','Montreal','93111','Delaware','Other','561-43-8853','366-163-9989','sean96@johnston-roberts.com','Unknown'),(4,'Katherine','Mcdowell','c','1959-12-30',3997,'Massey Pine','Chicoutimi','36628','North Dakota','Other','832-31-3526','991-164-4130','shannon51@yahoo.com','Unknown'),(5,'Laura','Cook','d','1961-05-19',8017,'Melissa Forges','Brossard','06429','Oregon','Female','650-69-9866','664-398-3044','martinezjacob@wilson.com','Unknown'),(6,'Sharon','Johnson','B','1996-10-07',9432,'Mary Cliff','Sherbrooke','29445','California','Female','663-39-5740','288-293-4059','brucemcdonald@hotmail.com','Unknown'),(7,'Kristina','Moore','k','1977-10-30',6411,'Wilson Mills','Chicoutimi','87743','Idaho','Other','014-61-6716','931-341-4525','paul42@hotmail.com','Unknown'),(8,'Chelsea','Nunez','L','1997-08-29',5314,'Jennifer Loaf','Brossard','98606','Nebraska','Female','849-84-1323','701-745-6493','hollymoore@walsh.org','Unknown'),(9,'Gabriel','Brown','S','1965-04-07',1649,'Rose Oval','Sherbrooke','74085','Rhode Island','Other','774-01-0638','324-146-9752','larry70@yahoo.com','Unknown'),(10,'Aaron','Smith','W','1954-09-11',597,'James Rest','Brossard','85601','Illinois','Male','895-39-4588','289-835-3029','alvarezsandra@miller.com','Unknown'),(11,'Melissa','Williams','n','2000-11-16',4933,'Grant Lakes','Chicoutimi','74880','Arizona','Female','867-96-9955','284-162-9251','xbowman@hotmail.com','Unknown'),(12,'Matthew','Oliver','c','1972-11-18',2776,'Edward Prairie','Sherbrooke','38450','Mississippi','Male','405-71-2125','907-792-3592','woodsjohn@gmail.com','Unknown'),(13,'Thomas','Randall','Z','1977-12-02',9325,'Timothy Squares','Chicoutimi','65740','Nevada','Other','039-39-5490','465-497-5111','courtneybennett@miller.com','Unknown'),(14,'Jennifer','Robinson','f','1979-08-07',5771,'Vanessa Green','Chicoutimi','77208','Wyoming','Other','171-56-3145','467-704-3168','brownmichelle@hotmail.com','Unknown'),(15,'Cindy','Garcia','D','1980-04-05',3656,'Payne Drive','Montreal','14230','Rhode Island','Female','500-19-9240','827-996-7789','frich@hotmail.com','Unknown'),(16,'Lisa','Johnson','j','1972-01-06',7984,'Megan Prairie','Brossard','39086','Virginia','Male','724-61-1088','606-433-6112','jonesdavid@smith-anthony.com','Unknown'),(17,'Audrey','Gregory','Z','1989-10-13',2139,'Julie Throughway','Brossard','27515','Maine','Female','549-77-6846','794-527-6180','olawson@gmail.com','Unknown'),(18,'Kendra','Cruz','y','1958-10-09',3253,'Danielle Crossroad','Chicoutimi','31820','Maine','Female','747-43-0910','805-286-2641','fbutler@love.com','Unknown'),(19,'Mario','Graves','P','1978-02-15',8534,'Patrick Trail','Chicoutimi','64768','Delaware','Male','062-79-7655','992-258-5561','montesjennifer@yahoo.com','Unknown'),(20,'Benjamin','Myers','x','1967-07-01',9955,'Kelly Roads','Montreal','10375','Arizona','Other','041-63-4185','759-569-8134','jerryfrank@chan.com','Unknown');
/*!40000 ALTER TABLE `donors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-15 11:06:15
